package com.example.buysell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuysellApplication {
	public static void main(String[] args) {
		SpringApplication.run(BuysellApplication.class, args);
	}
}
